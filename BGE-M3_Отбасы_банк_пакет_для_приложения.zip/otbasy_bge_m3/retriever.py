"""Dense FAQ retrieval with the trained BGE-M3 residual projection."""

import json
import os
from pathlib import Path
from threading import Lock

os.environ.setdefault("USE_TF", "0")
import numpy as np
import torch
from sentence_transformers import SentenceTransformer
from torch import nn
from torch.nn import functional as F

ROOT = Path(__file__).resolve().parent


class ResidualProjection(nn.Module):
    def __init__(self, dimension, rank):
        super().__init__()
        self.scale = dimension ** 0.5
        self.down = nn.Linear(dimension, rank, bias=False)
        self.up = nn.Linear(rank, dimension, bias=False)

    def forward(self, x):
        x = F.normalize(x, dim=1)
        update = self.up(F.gelu(self.down(x * self.scale))) / self.scale
        return F.normalize(x + update, dim=1)


class FAQRetriever:
    def __init__(self, root=ROOT, threads=2):
        root = Path(root)
        self.config = json.loads((root / "model.json").read_text(encoding="utf-8"))
        self.docs = json.loads((root / "assets" / "documents.json").read_text(encoding="utf-8"))
        self.index = np.load(root / "assets" / "index.npy", mmap_mode="r", allow_pickle=False)
        dim, rows, rank = (self.config[k] for k in ("dimension", "rows", "rank"))
        if self.index.shape != (rows, dim) or self.index.dtype != np.float32 or len(self.docs) != rows:
            raise ValueError("Размер индекса не совпадает с настройками пакета.")
        self.projection = ResidualProjection(dim, rank).eval()
        with np.load(root / "assets" / "adapter.npz", allow_pickle=False) as weights:
            self.projection.load_state_dict({key: torch.from_numpy(weights[key]) for key in weights.files})
        if "fbgemm" not in torch.backends.quantized.supported_engines:
            raise RuntimeError("Для этого индекса требуется сборка PyTorch с CPU-бэкендом FBGEMM.")
        torch.set_num_threads(threads)
        torch.backends.quantized.engine = "fbgemm"
        self.encoder = SentenceTransformer(self.config["model"], revision=self.config["revision"], device="cpu")
        self.encoder.max_seq_length = self.config["max_tokens"]
        torch.ao.quantization.quantize_dynamic(self.encoder, {nn.Linear}, dtype=torch.qint8, inplace=True)
        self._lock = Lock()

    @torch.inference_mode()
    def search(self, question, top_k=3):
        question = question.strip()
        if not question:
            raise ValueError("Введите вопрос.")
        if not 1 <= top_k <= 10:
            raise ValueError("top_k должен быть от 1 до 10.")
        with self._lock:
            embedding = self.encoder.encode([question], normalize_embeddings=True, convert_to_numpy=True)
            vector = self.projection(torch.from_numpy(embedding.astype(np.float32, copy=False))).numpy()[0]
        scores = self.index @ vector
        top = np.argsort(-scores, kind="stable")[:top_k]
        return [{**self.docs[i], "rank": rank, "cosine": float(np.clip(scores[i], -1.0, 1.0))}
                for rank, i in enumerate(top, start=1)]
