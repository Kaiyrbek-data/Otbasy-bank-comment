"""Run with python -m uvicorn app:app --host 127.0.0.1 --port 8000."""

from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from retriever import ROOT, FAQRetriever


@asynccontextmanager
async def lifespan(app):
    app.state.retriever = FAQRetriever()
    yield


app = FastAPI(title="Поиск ответов об Отбасы банке", version="1.0.0", lifespan=lifespan)


class Question(BaseModel):
    question: str = Field(min_length=1, max_length=4000)
    top_k: int = Field(default=3, ge=1, le=10)


@app.get("/", include_in_schema=False)
def demo():
    return FileResponse(ROOT / "demo.html", media_type="text/html")


@app.get("/health")
def health(request: Request):
    return {"status": "ready", "model": "BGE-M3 + обученный слой",
            "rows": request.app.state.retriever.config["rows"]}


@app.post("/search")
def search(body: Question, request: Request):
    if not body.question.strip():
        raise HTTPException(status_code=422, detail="Введите вопрос.")
    matches = request.app.state.retriever.search(body.question, body.top_k)
    return {"matches": matches}
